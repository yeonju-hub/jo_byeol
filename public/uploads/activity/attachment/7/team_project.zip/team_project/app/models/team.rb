class Team < ApplicationRecord
	has_one :admin
	has_many :uhts
	has_many :users, :through => :uhts

end
