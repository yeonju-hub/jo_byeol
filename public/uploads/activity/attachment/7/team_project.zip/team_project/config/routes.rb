Rails.application.routes.draw do
  resources :uhts
  resources :admins
  resources :teams
  devise_for :users
  # For details on the DSL available within this file, see https://guides.rubyonrails.org/routing.html
	
	root 'teams#index'
	
	get '/teams/:team_id/admin_connect' => 'teams#admin_connect', as: 'admin_connect'
end
